//
// Created by Sophia on 22.04.2020.
//

#ifndef UNTITLED_CONDITION_PARSER_H
#define UNTITLED_CONDITION_PARSER_H

#pragma once

#include "node.h"

#include <memory>
#include <iostream>

using namespace std;

shared_ptr<Node> ParseCondition(istream& is);

void TestParseCondition();

#endif //UNTITLED_CONDITION_PARSER_H
