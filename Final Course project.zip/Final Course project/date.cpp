//
// Created by Sophia on 22.04.2020.
//

#include "date.h"

#include <string>
#include <algorithm>

using namespace std;

bool IsDashSymbol(char s) {
    return s == '-';
}

string Date::ToString() const
{
    stringstream ss;
    ss << *this;
    return ss.str();
}

Date ParseDate(std::istream& is)
{
    string DATE;
    is >> DATE;
    int year, month, day;

    stringstream ss(DATE);

    ss >> year;
    ss.ignore(1);

    ss >> month;
    ss.ignore(1);

    ss >> day;

    return Date(year, month, day);
}



/*
#include "date.h"
#include <utility>
#include <regex>
#include <cmath>
#include <sstream>
#include <set>

#include <iomanip>

Date::Date(int day, int month, int year)
{
    this->DAY = day;
    this->MONTH = month;
    this->YEAR = year;
}

int Date::getDay() const
{
    return this->DAY;
}

int Date::getMonth() const
{
    return this->MONTH;
}

int Date::getYear() const
{
    return this->YEAR;
}

Date ParseDate(std::istream& is)
{
    string DATE;
    is >> DATE;
    int year, month, day;

    stringstream ss(DATE);

    ss >> year;
    ss.ignore(1);

    ss >> month;
    ss.ignore(1);

    ss >> day;

    return Date(year, month, day);
}

string Date::ToString() const
{
    stringstream ss;
    ss << *this;
    return ss.str();
}

ostream& operator<<(ostream& stream, const Date& date)
{
    string year = "";
    string month;
    string day;
    if (date.getMonth() < 10)
        month = "0";
    if (date.getDay() < 10)
        day = "0";

    for (int i = 1; i <= 3; i++)
    {
        if(date.getYear() < pow(10, i) && date.getYear() > pow(10, i-1))
        {
            for(int t = 0; t < i; t++)
            {
                year += "0";
            }
        }
    }

    stream << year << date.getYear() << "-" << month << date.getMonth() << "-" << day << date.getDay();
    return stream;
}*/