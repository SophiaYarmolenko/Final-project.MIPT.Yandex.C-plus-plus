//
// Created by Sophia on 22.04.2020.
//

#ifndef UNTITLED_DATABASE_H
#define UNTITLED_DATABASE_H
#pragma once

#include "date.h"

#include <vector>
#include <iostream>
#include <map>
#include <algorithm>
#include <string>
#include <iostream>
#include <utility>
#include <set>

using namespace std;

struct Entry
{
    Date date;
    string event;
};

ostream& operator<<(ostream& os, const Entry& entry);

class Database
{

public:
    void Add(const Date& date, const string& event);

    void Print(ostream& os) const;

    template<typename L>
    int RemoveIf(const L& predicate)
    {
        int Number = 0;

        for (auto it = storage.begin(); it != storage.end(); )
        {
            for(auto eventIt = (*it).second.second.begin(); eventIt != (*it).second.second.end(); )
            {
                if(predicate((*it).first, *(*eventIt)))
                {
                    storage[(*it).first].first.erase(*(*eventIt));
                    eventIt = storage[(*it).first].second.erase(eventIt);

                    ++Number;
                }
                else
                {
                    eventIt = next(eventIt);
                }
            }
            if((*it).second.first.size() == 0)
            {
                it = storage.erase(it);
            }
            else
            {
                it = next(it);
            }
        }

        return Number;
    }

    template <typename Predicate>
    vector<Entry> FindIf(const Predicate& predicate) const
    {
        vector<Entry> out;
        for (auto it = storage.begin(); it != storage.end(); it = next(it))
        {
            for(auto eventIt = (*it).second.second.begin(); eventIt != (*it).second.second.end(); eventIt = next(eventIt))
            {
                if(predicate((*it).first, *(*eventIt)))
                {
                    out.push_back({ (*it).first, *(*(eventIt)) });
                }
            }
        }
        return out;
    }

    string Last(const Date& date) const;

private:
    map<Date, std::pair<std::set<string>, std::vector<std::set<string>::iterator>>> storage;

};
#endif //UNTITLED_DATABASE_H
