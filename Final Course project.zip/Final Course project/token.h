//
// Created by Sophia on 22.04.2020.
//

#ifndef UNTITLED_TOKEN_H
#define UNTITLED_TOKEN_H
#pragma once

#include <sstream>
#include <vector>
using namespace std;

enum class TokenType {
    DATE,
    EVENT,
    COLUMN,
    LOGICAL_OP,
    COMPARE_OP,
    PAREN_LEFT,
    PAREN_RIGHT,
};

struct Token {
    const string value;
    const TokenType type;
};

vector<Token> Tokenize(istream& cl);

#endif //UNTITLED_TOKEN_H
