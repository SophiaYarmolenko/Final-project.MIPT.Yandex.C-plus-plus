//
// Created by Sophia on 22.04.2020.
//

#include "database.h"
ostream &operator<<(ostream &os, const Entry &entry)
{
    os << entry.date << " " << entry.event;
    return os;
}

void Database::Add(const Date &date, const string &event)
{
    if (storage.count(date))
    {
        auto insert_result = storage[date].first.insert(event);
        if (insert_result.second)
        {
            storage[date].second.push_back(insert_result.first);
        }
    }
    else
        {
            auto insert_result  = storage[date].first.insert(event);
            storage[date].second.push_back(insert_result.first);
        }
}

void Database::Print(ostream &os) const
{
    for(auto it = storage.begin(); it != storage.end(); it=next(it))
    {
        for(auto eventIt : (*it).second.second) {
            os << (*it).first << " " << *eventIt << endl;
        }
    }
}

string Database::Last(const Date& date) const
{
    auto it = storage.upper_bound(date);

    if (it == storage.begin())
    {
        return "No entries";
    }
    else
        {
            return (*prev(it)).first.ToString() + " " + (*(*prev(it)).second.second.back());
        }
}
